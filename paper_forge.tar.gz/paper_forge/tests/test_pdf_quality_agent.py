from __future__ import annotations

from pathlib import Path
import sys

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

from paper_forge.pdf_quality_agent import inspect_paper_artifacts


def test_pdf_quality_agent_flags_markdown_code_and_language_mismatch(tmp_path):
    tex_path = tmp_path / "paper.tex"
    tex_path.write_text(
        "```markdown\n"
        "assert not np.isnan(S).any()\n"
        "中文残留很多很多很多很多很多很多很多很多很多很多很多很多很多很多很多。\n",
        encoding="utf-8",
    )
    log_path = tmp_path / "paper.log"
    log_path.write_text("Overfull \\hbox (12.0pt too wide) in paragraph", encoding="utf-8")

    report = inspect_paper_artifacts(
        tex_path=tex_path,
        log_path=log_path,
        target_language="en",
    )
    kinds = {issue.kind for issue in report.issues}

    assert "markdown_fence" in kinds
    assert "code_like_prose" in kinds
    assert "language_mismatch" in kinds
    assert "overfull_hbox" in kinds
    assert report.passed is False
