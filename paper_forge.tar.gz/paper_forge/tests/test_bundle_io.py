from __future__ import annotations

import json
from pathlib import Path
import sys

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

from paper_forge.bundle_io import load_paper_bundle, paper_bundle_to_markdown


def test_load_lab_forge_bundle_as_standalone_paperforge_input(tmp_path):
    bundle_path = tmp_path / "paperforge_bundle.json"
    bundle_path.write_text(
        json.dumps(
            {
                "title": "Standalone Bundle",
                "abstract": "A structured upstream paper.",
                "sections": [
                    {
                        "heading": "5. Results",
                        "paragraphs": ["Accuracy is reported in Table 1."],
                        "figures": [
                            {"filename": "curve.png", "caption": "Learning curve"}
                        ],
                        "tables": [
                            {
                                "caption": "Metrics",
                                "headers": ["model", "accuracy"],
                                "rows": [["baseline", "0.91"]],
                            }
                        ],
                    }
                ],
                "references": ["Author et al. (2025). Example."],
            }
        ),
        encoding="utf-8",
    )

    paper = load_paper_bundle(bundle_path)
    markdown = paper_bundle_to_markdown(paper)

    assert paper["title"] == "Standalone Bundle"
    assert "![Learning curve](curve.png)" in markdown
    assert "| model | accuracy |" in markdown
    assert "Author et al. (2025). Example." in markdown
