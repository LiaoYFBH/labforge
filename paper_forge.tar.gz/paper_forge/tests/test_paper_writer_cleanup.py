from __future__ import annotations

from pathlib import Path
import sys

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

from paper_forge.config import LLMConfig
from paper_forge.paper_writer import (
    _clean_llm_section_output,
    _strip_llm_meta_prefix,
    _strip_llm_meta_suffix,
    parse_markdown_paper,
    structure_paper,
)


def test_parse_markdown_paper_strips_outer_markdown_fence_and_code_block():
    paper = parse_markdown_paper(
        """```markdown
# Test Paper

## Introduction

Reliable uncertainty estimation is important.

```python
assert not np.isnan(S).any()
```

## Conclusion

The method reports only finite metrics.
```""",
        image_names=[],
    )

    all_text = "\n".join(
        para
        for section in paper["sections"]
        for para in section.get("paragraphs", [])
    )
    assert "```" not in all_text
    assert "assert not" not in all_text
    assert "Reliable uncertainty estimation" in all_text


def test_structure_paper_forced_language_localizes_common_headings_without_rewrite():
    paper = structure_paper(
        """# 测试论文

## 引言

This paragraph is unchanged without an LLM rewrite.

## 方法与实现的验证

Validation text.
""",
        image_names=[],
        llm_config=LLMConfig(model="unused", api_key="unused"),
        rewrite=False,
        forced_language="en",
    )

    headings = [section["heading"] for section in paper["sections"]]
    assert "Introduction" in headings
    assert "Methodology and Validation" in headings


def test_strip_llm_meta_prefix_drops_expanded_word_version_lead():
    """Trajectory 5bfb6c8d leaked
        "Here is the expanded 800-word version incorporating all required
         elements while preserving the original content's technical rigor:"
    as the first sentence of the Introduction. The section noun ``version``
    must be recognized."""
    body = (
        "Here is the expanded 800-word version incorporating all required "
        "elements while preserving the original content's technical rigor:\n\n"
        "The classification of handwritten digits constitutes a cornerstone."
    )
    cleaned = _strip_llm_meta_prefix(body)
    assert cleaned.startswith("The classification of handwritten digits")
    assert "expanded 800-word version" not in cleaned


def test_strip_llm_meta_prefix_handles_markdown_bold_section_name():
    """Trajectory 5bfb6c8d also leaked
        "Here's the expanded **Analysis & Discussion** section (711 words),
         incorporating mechanistic explanations, ...:"
    The bold-wrapped section name must not block the prefix match."""
    body = (
        "Here's the expanded **Analysis & Discussion** section (711 words), "
        "incorporating mechanistic explanations, limitations, and actionable "
        "future directions while preserving the original arguments:\n\n"
        "Our comparative analysis establishes logistic regression as optimal."
    )
    cleaned = _strip_llm_meta_prefix(body)
    assert cleaned.startswith("Our comparative analysis")


def test_strip_llm_meta_suffix_drops_word_count_marker():
    body = (
        "Our analysis shows logistic regression dominates.\n\n"
        "*Word count: 1,128*"
    )
    cleaned = _strip_llm_meta_suffix(body)
    assert "Word count" not in cleaned
    assert cleaned.rstrip().endswith("dominates.")


def test_strip_llm_meta_suffix_drops_self_reflective_changelog():
    body = (
        "We conclude that resource constraints favor logistic regression.\n\n"
        "---\n\n"
        "This revision expands the discussion by:\n"
        "1. Adding mechanistic explanations\n"
        "2. Specifying limitations\n"
        "3. Proposing concrete future work\n"
        "4. Maintaining all original citations"
    )
    cleaned = _strip_llm_meta_suffix(body)
    assert "This revision expands" not in cleaned
    assert "1. Adding mechanistic" not in cleaned
    assert cleaned.rstrip().endswith("logistic regression.")


def test_strip_llm_meta_suffix_drops_chinese_math_appendix():
    body = (
        "本文证明经典方法在受限算力下仍具竞争力。\n\n"
        "数学补充（根据需要嵌入）：\n"
        "$$\n\\text{Margin} = y_i(w^Tx_i + b)\n$$"
    )
    cleaned = _strip_llm_meta_suffix(body)
    assert "数学补充" not in cleaned
    assert "Margin" not in cleaned
    assert cleaned.rstrip().endswith("仍具竞争力。")


def test_clean_llm_section_output_strips_both_ends():
    body = (
        "Here is the expanded 800-word version incorporating all required:\n\n"
        "Logistic regression achieves the strongest accuracy.\n\n"
        "*Word count: 800*"
    )
    cleaned = _clean_llm_section_output(body)
    assert cleaned.startswith("Logistic regression")
    assert "Word count" not in cleaned
    assert "expanded 800-word" not in cleaned
