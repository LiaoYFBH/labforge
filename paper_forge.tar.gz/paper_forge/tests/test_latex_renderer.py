from __future__ import annotations

from base64 import b64decode
from pathlib import Path
import sys

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

from paper_forge.latex_renderer import render_paper_to_tex


_ONE_PIXEL_PNG = b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO7+K6cAAAAASUVORK5CYII="
)


def test_render_paper_to_tex_prefers_renderable_figure_variant(tmp_path):
    paper = {
        "title": "Figure Variant Selection",
        "authors": [],
        "abstract": "",
        "keywords": [],
        "sections": [
            {
                "heading": "Results",
                "level": 1,
                "paragraphs": [],
                "figures": [
                    {"filename": "per_class_analysis.svg", "caption": "Vector caption"},
                    {"filename": "per_class_analysis.png", "caption": "Raster caption"},
                ],
                "tables": [],
            }
        ],
        "references": [],
    }
    images = {
        "per_class_analysis.svg": b"<svg></svg>",
        "per_class_analysis.png": _ONE_PIXEL_PNG,
    }

    tex_path = render_paper_to_tex(paper=paper, images=images, output_dir=tmp_path)
    tex = tex_path.read_text(encoding="utf-8")

    assert "figures/per_class_analysis.png" in tex
    assert "figures/per_class_analysis.svg" not in tex
    assert "Raster caption" in tex
    assert not (tmp_path / "figures" / "per_class_analysis.svg").exists()
    assert (tmp_path / "figures" / "per_class_analysis.png").exists()


def test_render_paper_to_tex_skips_unsupported_svg_without_alternative(tmp_path):
    paper = {
        "title": "Unsupported SVG",
        "authors": [],
        "abstract": "",
        "keywords": [],
        "sections": [
            {
                "heading": "Results",
                "level": 1,
                "paragraphs": [],
                "figures": [
                    {"filename": "only_chart.svg", "caption": "SVG only"},
                ],
                "tables": [],
            }
        ],
        "references": [],
    }
    images = {"only_chart.svg": b"<svg></svg>"}

    tex_path = render_paper_to_tex(paper=paper, images=images, output_dir=tmp_path)
    tex = tex_path.read_text(encoding="utf-8")

    assert "only_chart.svg" not in tex
    assert "\\begin{figure}[H]" not in tex
    assert not (tmp_path / "figures").exists()


def test_render_paper_to_tex_preserves_backslash_math_delimiters(tmp_path):
    paper = {
        "title": "Math Rendering",
        "authors": [],
        "abstract": "We optimize \\(\\mathcal{L}=\\|x\\|_2^2\\).",
        "keywords": [],
        "sections": [
            {
                "heading": "Method",
                "level": 1,
                "paragraphs": [
                    "The update is \\(x_{t+1}=x_t-\\eta \\nabla f(x_t)\\).",
                    "\\[\\hat{x}=\\arg\\min_x \\|Ax-y\\|_2^2\\]",
                ],
                "figures": [],
                "tables": [],
            }
        ],
        "references": [],
    }

    tex_path = render_paper_to_tex(paper=paper, images={}, output_dir=tmp_path)
    tex = tex_path.read_text(encoding="utf-8")

    assert "\\(\\mathcal{L}=\\|x\\|_2^2\\)" in tex
    assert "\\(x_{t+1}=x_t-\\eta \\nabla f(x_t)\\)" in tex
    assert "\\[\\hat{x}=\\arg\\min_x \\|Ax-y\\|_2^2\\]" in tex
    assert "\\textbackslash{}(" not in tex


def test_render_paper_to_tex_strips_markdown_fences_and_code_lines(tmp_path):
    paper = {
        "title": "No Code Artifacts",
        "authors": [],
        "abstract": "```markdown\nAbstract text.\n```",
        "keywords": [],
        "sections": [
            {
                "heading": "Method",
                "level": 1,
                "paragraphs": [
                    "```python\nassert not np.isnan(S).any()\n```",
                    "The validation checks finite outputs before reporting results.",
                ],
                "figures": [],
                "tables": [],
            }
        ],
        "references": [],
    }

    tex_path = render_paper_to_tex(paper=paper, images={}, output_dir=tmp_path)
    tex = tex_path.read_text(encoding="utf-8")

    assert "```" not in tex
    assert "assert not" not in tex
    assert "np.isnan" not in tex
    assert "The validation checks finite outputs" in tex


def test_render_paper_to_tex_wraps_long_math_to_linewidth(tmp_path):
    long_formula = (
        "\\log \\sum_{t=1}^{T} \\exp(f_{\\theta_t}(x)) = "
        "\\max_t f_{\\theta_t}(x) + \\log \\sum_{t=1}^{T} "
        "\\exp(f_{\\theta_t}(x)-\\max_t f_{\\theta_t}(x))"
    )
    paper = {
        "title": "Long Math",
        "authors": [],
        "abstract": "",
        "keywords": [],
        "sections": [
            {
                "heading": "Method",
                "level": 1,
                "paragraphs": [f"\\[{long_formula}\\]"],
                "figures": [],
                "tables": [],
            }
        ],
        "references": [],
    }

    tex_path = render_paper_to_tex(paper=paper, images={}, output_dir=tmp_path)
    tex = tex_path.read_text(encoding="utf-8")

    assert "\\resizebox{0.98\\linewidth}{!}" in tex
    assert long_formula in tex
